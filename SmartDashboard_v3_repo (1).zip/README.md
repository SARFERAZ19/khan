# Smart Learning Dashboard v3 (Kandahar)
React + Vite + Tailwind starter repo for the Smart Learning Dashboard (v3).

## Features
- Recharts charts (line, bar, pie)
- Tailwind CSS
- Sample data and components
- GitHub-ready structure

## Quick start
1. Install dependencies:

   ```bash
   npm install
   ```

2. Start dev server:

   ```bash
   npm run dev
   ```

3. Open `http://localhost:5173` in your browser.

## Build

```bash
npm run build
npm run preview
```

## Add your data
- Edit `src/App.jsx` sample data or implement CSV import/localStorage as needed.
