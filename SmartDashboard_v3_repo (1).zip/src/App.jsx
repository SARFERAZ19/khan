import React, { useState, useMemo } from 'react'
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts'

const SAMPLE_DB = [
  { date: '2025-11-03', skill: 'Video Editing', category: 'Editing', tool: 'Alight Motion', topic: 'Cuts', hours: 1.5, difficulty: 'Easy', status: 'Done', score: 80 },
  { date: '2025-11-04', skill: 'English', category: 'Language', tool: 'YouTube', topic: 'Vocab', hours: 1, difficulty: 'Medium', status: 'Done', score: 75 },
  { date: '2025-11-05', skill: 'Graphic Design', category: 'Design', tool: 'Photoshop', topic: 'Logo', hours: 2, difficulty: 'Medium', status: 'Planned', score: null },
  { date: '2025-11-06', skill: 'Video Editing', category: 'Editing', tool: 'DaVinci', topic: 'Color', hours: 2, difficulty: 'Hard', status: 'In Progress', score: 70 },
  { date: '2025-11-07', skill: 'English', category: 'Language', tool: 'App', topic: 'Speaking', hours: 1, difficulty: 'Easy', status: 'Done', score: 85 }
]

const COLORS = ['#1F4E78', '#63BE7B', '#FFA500', '#9B59B6', '#2ECC71']

export default function App(){ 
  const [data, setData] = useState(SAMPLE_DB)
  const [fromDate, setFromDate] = useState('2025-11-03')
  const [toDate, setToDate] = useState('2026-03-01')
  const [skillFilter, setSkillFilter] = useState('All')

  const filtered = useMemo(()=> {
    const f = new Date(fromDate)
    const t = new Date(toDate)
    return data.filter(d=>{
      const dt = new Date(d.date)
      const inRange = dt >= f && dt <= t
      const skillOk = skillFilter === 'All' ? true : d.skill === skillFilter
      return inRange && skillOk
    })
  }, [data, fromDate, toDate, skillFilter])

  const totalHours = useMemo(()=> filtered.reduce((s,r)=> s + (Number(r.hours)||0), 0), [filtered])
  const totalSessions = filtered.length
  const avgSession = totalSessions ? (totalHours/totalSessions).toFixed(2) : '0.00'
  const avgScore = useMemo(()=> {
    const scored = filtered.filter(d=>d.score!=null)
    if (!scored.length) return '-'
    const avg = scored.reduce((s,r)=> s + r.score, 0)/scored.length
    return Math.round(avg)
  }, [filtered])

  const hoursBySkill = useMemo(()=>{
    const map = {}
    filtered.forEach(r=> map[r.skill] = (map[r.skill]||0) + (Number(r.hours)||0))
    return Object.keys(map).map(k=> ({ skill: k, hours: map[k] })).sort((a,b)=> b.hours - a.hours)
  }, [filtered])

  const dailyHours = useMemo(()=>{
    const map = {}
    filtered.forEach(r=> map[r.date] = (map[r.date]||0) + (Number(r.hours)||0))
    return Object.keys(map).sort().map(d=> ({date: d, hours: map[d]}))
  }, [filtered])

  const catShare = useMemo(()=>{
    const map = {}
    filtered.forEach(r=> map[r.category] = (map[r.category]||0) + (Number(r.hours)||0))
    return Object.keys(map).map(k=> ({ name: k, value: map[k] }))
  }, [filtered])

  const skillsList = useMemo(()=> Array.from(new Set(data.map(d=>d.skill))), [data])

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-semibold text-[#1F4E78]">📊 Smart Learning Dashboard (v3.0)</h1>
          <div className="flex items-center gap-3">
            <label className="text-sm">From:</label>
            <input type="date" value={fromDate} onChange={e=>setFromDate(e.target.value)} className="p-2 border rounded" />
            <label className="text-sm">To:</label>
            <input type="date" value={toDate} onChange={e=>setToDate(e.target.value)} className="p-2 border rounded" />
            <select value={skillFilter} onChange={e=>setSkillFilter(e.target.value)} className="p-2 border rounded">
              <option value="All">All skills</option>
              {skillsList.map(s=> <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </header>

        <div className="grid grid-cols-4 gap-4 mb-6">
          <div className="bg-white p-4 rounded shadow">
            <div className="text-sm text-gray-500">Total Hours</div>
            <div className="text-2xl font-bold text-[#1F4E78]">{totalHours.toFixed(2)}</div>
          </div>
          <div className="bg-white p-4 rounded shadow">
            <div className="text-sm text-gray-500">Sessions</div>
            <div className="text-2xl font-bold">{totalSessions}</div>
          </div>
          <div className="bg-white p-4 rounded shadow">
            <div className="text-sm text-gray-500">Avg session (hrs)</div>
            <div className="text-2xl font-bold">{avgSession}</div>
          </div>
          <div className="bg-white p-4 rounded shadow">
            <div className="text-sm text-gray-500">Avg score</div>
            <div className="text-2xl font-bold">{avgScore}{avgScore!=='-' && '%'}</div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="col-span-2 bg-white p-4 rounded shadow">
            <h3 className="font-semibold mb-2">Daily Learning Hours</h3>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={dailyHours}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="hours" stroke="#1F4E78" strokeWidth={3} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-semibold mb-2">Top Skills (hours)</h3>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={hoursBySkill.slice(0,5)} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis type="category" dataKey="skill" />
                <Tooltip />
                <Bar dataKey="hours">
                  {hoursBySkill.slice(0,5).map((_, idx) => (<Cell key={idx} fill={COLORS[idx % COLORS.length]} />))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="col-span-1 bg-white p-4 rounded shadow">
            <h3 className="font-semibold mb-2">Category Share</h3>
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={catShare} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} label>
                  {catShare.map((entry, idx) => (<Cell key={`cell-${idx}`} fill={COLORS[idx % COLORS.length]} />))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-semibold mb-2">Database (records)</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-left text-gray-600">
                  <tr>
                    <th className="pr-4">Date</th><th className="pr-4">Skill</th><th className="pr-4">Tool</th><th className="pr-4">Topic</th><th className="pr-4">Hours</th><th className="pr-4">Status</th><th className="pr-4">Score</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((r,i)=> (
                    <tr key={i} className="border-t"><td className="py-2">{r.date}</td><td className="py-2">{r.skill}</td><td className="py-2">{r.tool}</td><td className="py-2">{r.topic}</td><td className="py-2">{r.hours}</td><td className="py-2">{r.status}</td><td className="py-2">{r.score ?? '-'}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-semibold mb-2">Planner (quick view)</h3>
            <div className="text-sm text-gray-600 mb-2">Planner and other tabs are available in the GitHub repo.</div>
            <div className="space-y-2">
              {Array.from({length:7}).map((_,i)=> (
                <div key={i} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                  <div><div className="font-medium">{new Date(Date.now() + i*24*3600*1000).toLocaleDateString()}</div><div className="text-xs text-gray-500">Sample task — Edit video / Practice English</div></div>
                  <div className="text-right"><div className="text-sm font-semibold">1.5h</div><div className="text-xs text-gray-500">Planned</div></div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </div>
  )
}
